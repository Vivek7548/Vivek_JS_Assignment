// Q 1 - write program in js to find maximum between 3 numbers.

var num1 = 5,
  num2 = 10,
  num3 = 15;
if (num1 > num2 && num1 > num3) {
  console.log("number 1 is greater");
} else if (num2 > num1 && num2 > num3) {
  console.log("number 2 is grater");
} else {
  console.log("number 3 is greater");
}

// 2.write in js to check whether a year is leap or not.
var year = 2008;
if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) {
  console.log("Leap year");
} else {
  console.log("not leap year");
}

// 3.write in js if the alphabet is vowel or consonant.
var alphabate = "b";
if (
  alphabate === "a" ||
  alphabate === "e" ||
  alphabate === "i" ||
  alphabate === "o" ||
  alphabate === "u"
) {
  console.log("Vowel");
} else {
  console.log("consonant");
}

// // 4.write in js using switchcase to print which day of the month it is.
var day = "7";
switch (day) {
  case "1":
    console.log("1st day in month");
    break;
  case "2":
    console.log("2 day in month");
    break;
  case "3":
    console.log("3 day in month");
    break;
  case "4":
    console.log("4 day in month");
    break;
  case "5":
    console.log("5 day in month");
    break;
  default:
    console.log("not valid day");
}

// 5.write in js to count total number of denominations in a given amount .( No of notes and coins should be minimum).

var amount = 2420;

var notes500 = 0,
  notes200 = 0,
  notes100 = 0,
  notes50 = 0,
  notes20 = 0,
  notes10 = 0,
  notes5 = 0,
  coins2 = 0,
  coins1 = 0;

if (amount >= 500) {
  notes500 = Math.floor(amount / 500);
  amount = amount % 500;
}
if (amount >= 200) {
  notes200 = Math.floor(amount / 200);
  amount = amount % 200;
}
if (amount >= 100) {
  notes100 = Math.floor(amount / 100);
  amount = amount % 100;
}
if (amount >= 50) {
  notes50 = Math.floor(amount / 50);
  amount = amount % 50;
}
if (amount >= 20) {
  notes20 = Math.floor(amount / 20);
  amount = amount % 20;
}
if (amount >= 10) {
  notes10 = Math.floor(amount / 10);
  amount = amount % 10;
}
if (amount >= 5) {
  notes5 = Math.floor(amount / 5);
  amount = amount % 5;
}
if (coins2 >= 2) {
  coins2 = Math.floor(amount / 2);
  amount = amount % 2;
}
if (coins1 >= 1) {
  coins1 = Math.floor(amount / 1);
  amount = amount % 1;
}

console.log("Denominations:");
console.log("500 Rupee Notes:", notes500);
console.log("200 Rupee Notes:", notes200);
console.log("100 Rupee Notes:", notes100);
console.log("50 Rupee Notes:", notes50);
console.log("20 Rupee Notes:", notes20);
console.log("10 Rupee Notes:", notes10);
console.log("5 Rupee Notes:", notes5);
console.log("2 Rupee Coins:", coins2);
console.log("1 Rupee Coins:", coins1);

// 6 WAP in js to calculate the power of x raised to y.
var x = 4;
var y = 4;
var result = 1;
for (var i = 1; i <= y; i++) {
  result *= x;
}
console.log(`${x} raised to the power ${y} is ${result}`);

// 7. Write a program in js to calculate the hcf of two numbers. program to find the HCF or GCD of two integers
var hcf;
var num1 = 72;
var num2 = 60;
for (var i = 1; i <= num1 && i <= num2; i++) {
  if (num1 % i == 0 && num2 % i === 0) {
    hcf = i;
  }
}
console.log(`hcf of ${num1} and ${num2} is ${hcf}`);

// 8. Write a program in js to calculate the factorial of a number.
var number = 5;
var factorial = 1;
for (var i = 1; i <= number; i++) {
  factorial *= i;
}
console.log(factorial);

// 9. Write a program in js to calculate the sum of the series  9+99+999+9999 .... n.
var series = [1, 2, 3, 4, 5];
var sum = 0;
for (var i = 0; i < series.length; i++) {
  sum += series[i];
}
console.log(sum);

//10. WAP in js to check if a number is positive or negative. Zero is considered as positive

var number = 5;
if (number > 0) {
  console.log("Positive number");
} else if (number < 0) {
  console.log("Negative number");
} else {
  console.log(" number is 0");
}

// 11.  write a program  in js to accept sp and cp of a product and print the profit or loss accordingly

var sp = 15;
var cp = 10;
var profit = sp - cp;
if (profit > 0) {
  console.log("profit is", sp - cp);
} else if (profit < 0) {
  console.log("loss is", cp - sp);
} else {
  console.log(`no profit or loss`);
}

// 12 check saturday is weekend or weekdays else print invalid day
var a = "monday";
var b = "tuesday";
var c = "wensday";
var d = "thusday";
var e = "friday";
var f = "saturday";
var g = "sunday";

if (f === "saturday") {
  console.log("Weekends");
} else if (f >= a && f <= e) {
  console.log("weekday");
} else {
  console.log("Invalid day");
}

// 13  WAP in js to compare two numbers
var num1 = 10;
var num2 = 5;
if (num1 > num2) {
  console.log("num1 is grater");
} else {
  console.log("num2 is grater");
}

// 14 1 and 100 5, 10, 15, 20, ..........100 for loop
var num = 5;
for (var i = num; i <= 100; i += 5) {
  console.log(i);
}

// 15. prime numbers or not
var number = 5;
var isPrime = true;
for (var i = 2; i <= Math.sqrt(number); i++) {
  if (number % i == 0) {
    console.log("number is not prime");
    isPrime = false;
  }
}
if (isPrime != false) console.log("number is prime");

// 16 number is perfect square or not
var number = 24;
var squareroot = Math.sqrt(number);
if (squareroot === parseInt(squareroot)) {
  console.log("perfect squre");
} else {
  console.log("not perfect square");
}

// 17 reverse a string using for loop
var string = "vivek";
var reverse = "";
for (var i = string.length - 1; i >= 0; i--) {
  reverse += string[i];
}
console.log(reverse);

// .18 count the number of digits in the string
var number = 1234;
var count = 0;
while (number !== 0) {
  number = Math.floor(number / 10);
  count++;
}
console.log(count);

//19  programe to check number is armstrong
var num = 153;
var que = num;
var remainder;
var sum = 0;
while (que !== 0) {
  remainder = que % 10;
  que = Math.floor(que / 10);
  sum = sum + Math.pow(remainder, 3);
}
if (sum === num) {
  console.log("number is armstrong number");
} else {
  console.log("number is not armstrong number");
}

// 20 check string is palindrome or not
var string = "mom";
var reverse = "";
for (var i = string.length - 1; i >= 0; i--) {
  reverse += string[i];
}
if (reverse === string) {
  console.log("string is palidrome");
} else {
  console.log("string is not palidrome");
}

// 21 Write a program in js to capitalise every alternate character of a string given that characters in the string will only be letters or spaces.

var string = "vivekhi";
var output = "";
for (var i = 0; i < string.length; i++) {
  if (i % 2 === 0) {
    output += string.charAt(i).toUpperCase();
  } else {
    output += string.charAt(i);
  }
}
console.log(output);

// 22 Write a program to remove nth character from a string
var str = "example";
var n = 2;

if (n >= 0 && n < str.length) {
  var removedChar = str.charAt(n);
  var modifiedStr = str.slice(0, n) + str.slice(n + 1);

  console.log("Original string:", str);
  console.log("Character removed:", removedChar);
  console.log("Modified string:", modifiedStr);
} else {
  console.log("Invalid index.");
}

// 23 check string content even number of characters

var string = "hellow words";
if (string.length % 2 == 0) {
  console.log("string content even character");
} else {
  console.log("string  content odd character");
}

//24 to count the number of words in the string

var sentense = "vivek is good boy";
sentense = sentense.trim();

var words = sentense.split(/\s+/);
var count = words.length;
console.log(count);

// 25 remove space in string
var str = "vivek hi ";
var result = "";
for (var i = 0; i < str.length; i++) {
  if (str[i] !== " ") {
    result += str[i];
  }
}
console.log(result);

// 26 check string only contains digits
var str = "12345";
var isdigit = "true";

for (var i = 0; i < str.length; i++) {
  if (str[i] < "0" || str[i] > "9") {
    isdigit = "false";
    break;
  }
}

console.log(isdigit, "it contents digit");

// 27 count no of vowels in the string
var string = "vivek";
var vowels = 0;
for (var i = 0; i < string.length; i++) {
  var char = string[i].toLowerCase();
  if (
    char === "a" ||
    char === "e" ||
    char === "i" ||
    char === "o" ||
    char === "u"
  ) {
    vowels++;
  }
}
console.log("Number of vowels in the string:", vowels);

// 28 Check if num is a  of a power of 2

var num = 16;
var power = true;

if (num > 0 && (num & (num - 1)) === 0) {
  power = true;
} else {
  power = false;
}
console.log(power, "power of 2");

// 29   check if a string is in upper case or not

var str = "VIVEK";
var isupper = true;
for (var i = 0; i < str.length; i++) {
  if (str[i] !== str[i].toUpperCase()) {
    isupper = false;
    break;
  }
}
console.log(isupper, "it is upper");

// 30 star pattern
// *
// **
// ***
// ****
// *****
var num = 5;
for (var i = 1; i <= num; i++) {
  var line = "";
  for (var j = 1; j <= i; j++) {
    line = line + "*";
  }
  console.log(line);
}

// 31 star pattern
var num = 1;
for (var i = 5; i >= num; i--) {
  var line = "";
  for (var j = 1; j <= i; j++) {
    line += "*";
  }
  console.log(line);
}

// 32
//   *
//  ***
// *****
//  ***
//   *

var n = 3;

for (var i = 1; i <= n; i++) {
  var line = "";
  for (var j = n; j > i; j--) {
    line = line + " ";
  }
  for (var k = 1; k <= 2 * i - 1; k++) {
    line = line + "*";
  }
  console.log(line);
}

for (var i = n - 1; i >= 1; i--) {
  var line = "";
  for (var j = n; j > i; j--) {
    line = line + " ";
  }
  for (var k = 1; k <= 2 * i - 1; k++) {
    line = line + "*";
  }
  console.log(line);
}

// 33
// *****
//  ***
//   *
var n = 5;

for (var i = n; i >= 1; i--) {
  var line = "";
  for (var j = n; j > i; j--) {
    line = line + " ";
  }
  for (var k = 1; k <= 2 * i - 1; k++) {
    line = line + "*";
  }
  console.log(line);
}

//34 Write a program in js to check if two strings are anagram or not

/*
bored, robed
night, thing
arc, car
*/

var s1 = "night",
  s2 = "thing";

if (s1.length !== s2.length) {
  console.log("They are not anagram");
} else {
  var count1 = [],
    count2 = [];
  for (var i = 0; i < 256; i++) {
    count1[i] = 0;
    count2[i] = 0;
  }

  for (var i = 0; i < s1.length; i++) {
    var ch1 = s1.charCodeAt(i);
    var ch2 = s2.charCodeAt(i); // 110
    count1[ch1]++;
    count2[ch2]++;
  }

  var flag = true;

  for (var i = 0; i < 256; i++) {
    if (count1[i] !== count2[i]) {
      console.log("They are not anagrams");
      flag = false;
      break;
    }
  }

  if (flag) {
    console.log("They are anagrams");
  }
}

// 35
// / write program in js to print all the prime numbers between 1 to 100
function prime(a, b) {
  for (var number = a; number <= b; number++) {
    var isPrime = true;
    for (var i = 2; i <= Math.sqrt(number); i++) {
      if (number % i === 0) {
        isPrime = false;
        break;
      }
    }
    if (isPrime && number > 1) {
      console.log(number);
    }
  }
}

var a = 1;
var b = 100;
prime(a, b);

//36.  0, 1, 1, 2, 3, 5, 8, 13, 21 ...

// Generate fibonacci series upto n terms
function fibonacciSeries(n) {
  var fibSeries = [0, 1];
  for (var i = 2; i < n; i++) {
    var ele = fibSeries[i - 1] + fibSeries[i - 2];
    fibSeries.push(ele);
  }
  return fibSeries;
}

var n = 5;
var result = fibonacciSeries(n);
console.log(result);
